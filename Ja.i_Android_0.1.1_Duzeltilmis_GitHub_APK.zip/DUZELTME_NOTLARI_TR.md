# Ja.i 0.1.1 — Düzeltme notları

Bu paket, mevcut Ja.i Android/Java kaynak projesinin yapısı korunarak güncellendi.

## Düzeltilen noktalar

1. **Mesaj gönderme dayanıklılığı:** Arka plan yanıtı sırasında beklenmeyen hata oluştuğunda gönder düğmesinin kilitli kalması önlendi. Kapanmış görev kuyruğunda da düğme yeniden açılır.
2. **Veritabanı yaşam döngüsü:** Activity kapanırken arka plan görevi hâlâ sohbet veritabanına yazıyorsa veritabanı erkenden kapatılmaz.
3. **İnternet algılama:** Sadece ağ arayüzü bulunması yeterli sayılmaz; Android'in doğrulanmış internet bağlantısı kontrol edilir.
4. **Hafıza araması:** “Ne hatırlıyorsun?” veya “Hafızada ara” gibi genel sorgularda gereksiz kelimelerin not aramasını bozması önlendi; sorgusuz istek en son kayıtları listeler.
5. **Kod ön kontrolü:** Yorum ve dizge içindeki `{}`, `()` ve `[]` karakterleri gerçek kod ayraçları gibi sayılmaz. Bu kontrol hâlâ derleyici değildir.
6. **Web sonuçları:** Arama sonucunda eksik özetin sonraki başlıkla karışması önlendi. Gösterilen tarih arama zamanıdır; yayın tarihi gibi sunulmaz.
7. **Dil algılama ve Java uyumluluğu:** JavaScript önce kontrol edilir, kod çiti etiketleri algılanır ve eski Türkçe `Locale` kurucuları güncellenir.
8. **Derleme akışı:** ZIP'e GitHub Actions iş akışı eklendi. İş akışı GitHub runner üzerinde JDK 17, Android SDK Platform 35 ve Gradle 8.9 kurup `assembleDebug` çalıştırır ve debug APK'yı artifact olarak yükler.

## Ana dosya değişiklikleri

- `Ja.i/app/src/main/java/com/jai/assistant/MainActivity.java`
- `Ja.i/app/src/main/java/com/jai/assistant/engine/BrainEngine.java`
- `Ja.i/app/src/main/java/com/jai/assistant/engine/CodeLabEngine.java`
- `Ja.i/app/src/main/java/com/jai/assistant/engine/LocalSearchEngine.java`
- `Ja.i/app/src/main/java/com/jai/assistant/engine/ModelEngine.java`
- `Ja.i/app/src/main/java/com/jai/assistant/engine/TaskPlanner.java`
- `Ja.i/app/src/main/java/com/jai/assistant/tools/WebResearchEngine.java`
- `Ja.i/app/build.gradle`
- `Ja.i/app/src/main/AndroidManifest.xml`
- `Ja.i/README_TR.md`, `Ja.i/APK_OLUSTUR_TELEFON_TR.md`, `Ja.i/TEST_RAPORU_TR.md`
- `.github/workflows/android.yml`

## Bilinen sınırlar

Bu sürümde genel amaçlı bir dil modeli yoktur. Gerçek APK derlemesi ve telefon testi henüz yapılmamıştır. GitHub Actions debug APK üretir; imzalı mağaza sürümü oluşturmaz. GitHub deposuna ZIP'in kendisini koymak yeterli değildir; ZIP çıkarılıp içindeki `.github` ve `Ja.i` klasörleri depo köküne yüklenmelidir.
