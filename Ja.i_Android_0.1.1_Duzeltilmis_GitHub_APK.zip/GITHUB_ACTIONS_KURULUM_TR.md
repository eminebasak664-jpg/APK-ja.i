# GitHub'dan Ja.i APK alma

1. ZIP'in tamamını çıkar.
2. Çıkan `.github` klasörünü ve `Ja.i` klasörünü aynı GitHub deposunun köküne yükle. Bu iki klasör aynı seviyede olmalı.
3. GitHub deposunda Actions sekmesine gir.
4. Solda **Ja.i Android APK** iş akışını aç.
5. **Run workflow** ile derlemeyi başlat. Ana dala push yapıldığında da otomatik çalışır.
6. Tamamlanan çalıştırmayı aç; Artifacts bölümünden `Ja.i-debug-apk` dosyasını indir.
7. Artifact ZIP'ini çıkar. `app-debug.apk` dosyası Ja.i uygulamasının kurulum paketidir.

Not: Yalnızca ZIP dosyasını repoya yüklemek yetmez. ZIP'in içindeki `.github` ve `Ja.i` klasörlerinin açılmış hâlde repoda bulunması gerekir. Bu iş akışı debug APK üretir; yayın imzası eklemez.
