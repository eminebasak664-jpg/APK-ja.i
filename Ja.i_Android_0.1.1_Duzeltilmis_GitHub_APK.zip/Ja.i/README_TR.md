# Ja.i — Android/Java yerel asistan başlangıç projesi

**Paket:** `com.jai.assistant`  
**Sürüm:** `0.1.1`  
**Öncelik:** çalışan temel, yerel veri ve dürüst yetenek sınırları.

Bu kaynak paketi ilk geliştirme aşamasıdır; kullanıcının tarif ettiği tüm nihai sistem değildir. Uygulama adı **Ja.i** olarak ayarlanmıştır. Haricî yapay zekâ API'si veya indirilmiş hazır bir dil modeli kullanmaz.

## Bu aşamada bulunan özellikler

- Java ve yerel Android XML arayüzü; ana arayüz WebView kullanmaz.
- Flash/Think modu ve Hızlı/Orta/Maksimum/Derin seçimleri. Think, mevcut araçlarla bir işlem planı/özeti gösterir; bağımsız bir büyük dil modeli değildir.
- Ara kapalıyken web isteği başlatmama; Ara açıkken DuckDuckGo HTML arama başlıkları, kısa özetleri ve bağlantılarını alma. Arama zamanı gösterilir; yayın tarihi veya tam sayfa doğrulaması varmış gibi davranılmaz.
- Sohbet mesajlarını SQLite veritabanında kalıcı tutma.
- `hatırla: ...` komutuyla yerel nota kaydetme; `hafızada ara ...` ile arama; arama sözü verilmeden hafıza istendiğinde son notları gösterme.
- Dört işlem ve parantezleri destekleyen yerel matematik ayrıştırıcısı.
- `öğren: ...` ile kalıcı öğrenme-görevi kuyruğuna kayıt ekleme. Bu yalnızca kuyruğa eklemedir; otomatik web araştırması veya model eğitimi değildir.
- Küçük Naive Bayes istek türü sınıflandırıcısı. `öğret-intent:etiket|örnek cümle` yeni sınıflandırma örneği kaydeder; genel dil üretimini eğitmez.
- TXT, Markdown, Java, XML, JSON, Gradle, JS, CSS, HTML, Python ve benzeri metin dosyalarını 1 MiB sınırıyla ekleme.
- Sohbeti Android dosya seçicisiyle TXT olarak dışa aktarma.
- Cihaz kaynakları hakkında yaklaşık bilgi ve yorum/dizge içeriğini atlayan basit statik ayraç kontrolü. Bu bir derleyici değildir.
- Mesaj işleme hatalarında gönder düğmesinin yeniden etkinleştirilmesi ve etkin görev sürerken veritabanının erkenden kapatılmaması.

## Henüz tamamlanmayanlar

- Genel amaçlı doğal dil üretimi veya güçlü yerel büyük dil modeli yok.
- Flash ve Think ayrı dil modelleri değil; mevcut yerel motorun iki çalışma biçimi.
- Web araştırması bu sürümde arama sonuçlarıyla sınırlıdır; kaynak sayfaların tamamı okunup bağımsız doğrulanmaz.
- Otomatik konu araştırması, öğrenilen bilgiyi doğrulama ve model ağırlıklarını eğitme henüz uygulanmadı.
- Fotoğraf, PDF, ZIP, ses ve video içeriğini anlama yok.
- Genel kod üretimi, güvenli kod çalıştırma ve APK derleme uygulamanın içinde yok.
- Görsel/video üretimi ve çok kullanıcılı mesajlaşma sunucusu yok.
- Devam ettirilebilir çok aşamalı görev yürütücüsü yok.

## GitHub üzerinden APK oluşturma

ZIP'in üst düzeyinde `.github/workflows/android.yml` ve `Ja.i/` klasörü bulunur. ZIP'i çıkarıp **iki öğeyi de** GitHub deposunun köküne yükle: `.github` klasörü ve `Ja.i` klasörü. Daha sonra GitHub'da **Actions → Ja.i Android APK → Run workflow** yolunu kullan. Ana dala yeni kod gönderildiğinde de derleme otomatik başlar.

Başarılı işlem sonunda `Ja.i-debug-apk` adlı Actions artifact'ini indirip içinden `app-debug.apk` dosyasını çıkar. Bu bir debug APK'dır; imzalı yayın sürümü değildir.

## Telefonda yerel derleme

`APK_OLUSTUR_TELEFON_TR.md` dosyasındaki adımları izle. Proje klasöründe terminal açıp `sh ./build-apk.sh` komutunu çalıştırabilirsin. Gerekli JDK 17, Android SDK Platform 35 ve internet bağlantısı sağlanmalıdır.

## Sürüm ve Android uyumluluğu

`minSdk 26` Android 8.0 (Oreo) ve üzerini hedefler. `targetSdk 34`, `compileSdk 35` olarak ayarlanmıştır.

## Veri ve gizlilik

Sohbet, hafıza ve sınıflandırıcı örnekleri cihazın yerel SQLite veritabanında tutulur. Android sistem yedeklemesi bu sürümde `allowBackup=false` ile kapalıdır. Ara özelliği açılır ve web sorgusu gönderilirse sorgu DuckDuckGo'ya gider; hassas bilgi içeren sorgularda Ara'yı kapalı tut. Gizli yapay zekâ sağlayıcısı çağrısı yoktur.
