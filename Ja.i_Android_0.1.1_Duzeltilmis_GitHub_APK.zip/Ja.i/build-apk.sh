#!/usr/bin/env sh
set -eu
APP_HOME=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$APP_HOME"
if ! command -v java >/dev/null 2>&1; then
  echo "HATA: Java/JDK bulunamadı. JDK 17 kur ve yeniden dene." >&2
  exit 1
fi
printf '%s\n' 'Ja.i debug APK derlemesi başlatılıyor...'
sh ./gradlew assembleDebug
APK="$APP_HOME/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  printf '\n%s\n' 'BAŞARILI: APK oluşturuldu:' "$APK"
else
  printf '\n%s\n' 'Derleme komutu tamamlandı ancak beklenen APK bulunamadı.' >&2
  exit 2
fi
