package com.jai.assistant.engine;

import com.jai.assistant.data.MemoryDatabase;
import com.jai.assistant.data.MemoryEntry;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

/** Kullanıcının kaydettiği yerel bilgileri anahtar kelimeler üzerinden arar. */
public final class LocalSearchEngine {
    private final MemoryDatabase database;

    public LocalSearchEngine(MemoryDatabase database) {
        this.database = database;
    }

    public String search(String query, int limit) {
        boolean showRecent = query == null || query.trim().isEmpty();
        List<MemoryEntry> entries = showRecent
                ? database.getRecentMemories(limit)
                : database.searchMemories(query, limit);
        if (entries.isEmpty()) {
            return showRecent
                    ? "Yerel hafızada henüz kayıtlı bir not yok. 'hatırla: ...' yazarak not ekleyebilirsin."
                    : "Yerel hafızada bu sorguyla eşleşen bir kayıt bulamadım.";
        }
        StringBuilder result = new StringBuilder(showRecent
                ? "Son kaydedilen yerel hafıza notları:\n"
                : "Yerel hafızada bulunan kayıtlar:\n");
        DateFormat format = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
        for (MemoryEntry entry : entries) {
            result.append("\n• ").append(entry.title).append("\n")
                    .append(entry.content).append("\n")
                    .append("Kaynak: ").append(entry.source)
                    .append(" · ").append(entry.verified ? "doğrulanmış olarak işaretli" : "bağımsız doğrulama yok")
                    .append(" · ").append(format.format(new Date(entry.updatedAt))).append("\n");
        }
        return result.toString().trim();
    }
}
