package com.jai.assistant.engine;

/** Küçük, bağımlılıksız dört işlem ayrıştırıcısı. String'i kod olarak çalıştırmaz. */
public final class ExpressionEvaluator {
    private final String input;
    private int position;

    private ExpressionEvaluator(String input) {
        this.input = input == null ? "" : input;
    }

    public static double evaluate(String expression) {
        ExpressionEvaluator parser = new ExpressionEvaluator(expression);
        double value = parser.parseExpression();
        parser.skipSpaces();
        if (parser.position != parser.input.length()) {
            throw new IllegalArgumentException("İfade çözümlenemedi; beklenmeyen karakter: " + parser.input.charAt(parser.position));
        }
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            throw new IllegalArgumentException("Sonuç geçerli bir sayı değil.");
        }
        return value;
    }

    private double parseExpression() {
        double value = parseTerm();
        while (true) {
            skipSpaces();
            if (consume('+')) value += parseTerm();
            else if (consume('-')) value -= parseTerm();
            else return value;
        }
    }

    private double parseTerm() {
        double value = parseUnary();
        while (true) {
            skipSpaces();
            if (consume('*')) {
                value *= parseUnary();
            } else if (consume('/')) {
                double divisor = parseUnary();
                if (Math.abs(divisor) < 1e-12) throw new IllegalArgumentException("Sıfıra bölme yapılamaz.");
                value /= divisor;
            } else {
                return value;
            }
        }
    }

    private double parseUnary() {
        skipSpaces();
        if (consume('+')) return parseUnary();
        if (consume('-')) return -parseUnary();
        return parsePrimary();
    }

    private double parsePrimary() {
        skipSpaces();
        if (consume('(')) {
            double value = parseExpression();
            skipSpaces();
            if (!consume(')')) throw new IllegalArgumentException("Parantez kapatılmamış.");
            return value;
        }

        int start = position;
        boolean digitSeen = false;
        boolean dotSeen = false;
        while (position < input.length()) {
            char c = input.charAt(position);
            if (Character.isDigit(c)) {
                digitSeen = true;
                position++;
            } else if (c == '.' || c == ',') {
                if (dotSeen) break;
                dotSeen = true;
                position++;
            } else {
                break;
            }
        }
        if (!digitSeen) throw new IllegalArgumentException("Sayı bekleniyordu.");
        String number = input.substring(start, position).replace(',', '.');
        try {
            return Double.parseDouble(number);
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException("Sayı okunamadı: " + number);
        }
    }

    private boolean consume(char expected) {
        if (position < input.length() && input.charAt(position) == expected) {
            position++;
            return true;
        }
        return false;
    }

    private void skipSpaces() {
        while (position < input.length() && Character.isWhitespace(input.charAt(position))) position++;
    }
}
