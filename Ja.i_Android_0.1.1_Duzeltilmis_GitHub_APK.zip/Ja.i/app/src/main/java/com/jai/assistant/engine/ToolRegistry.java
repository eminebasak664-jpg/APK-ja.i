package com.jai.assistant.engine;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Gerçekten mevcut yerel işlevleri isimleriyle kaydeden basit araç kayıt sistemi. */
public final class ToolRegistry {
    public interface Tool {
        String execute(String input) throws Exception;
    }

    private final Map<String, Tool> tools = new LinkedHashMap<>();

    public void register(String name, Tool tool) {
        if (name == null || name.trim().isEmpty() || tool == null) {
            throw new IllegalArgumentException("Araç adı ve işlevi zorunludur.");
        }
        tools.put(name, tool);
    }

    public boolean contains(String name) {
        return tools.containsKey(name);
    }

    public String execute(String name, String input) throws Exception {
        Tool tool = tools.get(name);
        if (tool == null) throw new IllegalArgumentException("Kayıtlı olmayan araç: " + name);
        return tool.execute(input == null ? "" : input);
    }

    public Map<String, Tool> registeredTools() {
        return Collections.unmodifiableMap(tools);
    }
}
