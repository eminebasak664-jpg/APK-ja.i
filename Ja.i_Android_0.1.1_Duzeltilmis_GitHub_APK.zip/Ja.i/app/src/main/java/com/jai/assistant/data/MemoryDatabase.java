package com.jai.assistant.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/** Kalıcı yerel sohbet, hafıza, görev ve küçük sınıflandırıcı eğitim kayıtları. */
public final class MemoryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "jai_local.db";
    private static final int DATABASE_VERSION = 1;

    public MemoryDatabase(Context context) {
        super(context.getApplicationContext(), DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, content TEXT NOT NULL, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE memories (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, content TEXT NOT NULL, source TEXT NOT NULL, verified INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL, details TEXT NOT NULL, updated_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE training_examples (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, label TEXT NOT NULL, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_messages_created ON messages(created_at)");
        db.execSQL("CREATE INDEX idx_memories_updated ON memories(updated_at)");
        db.execSQL("CREATE INDEX idx_tasks_updated ON tasks(updated_at)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Sürümler ilerledikçe veriyi silmek yerine açık ve artımlı geçişler eklenecek.
        // Bu ilk sürümde eski bir şema bulunmadığından tablo silinmez.
    }

    public synchronized long saveMessage(String role, String content) {
        ContentValues values = new ContentValues();
        values.put("role", role);
        values.put("content", content);
        values.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("messages", null, values);
    }

    public synchronized List<ChatMessage> getRecentMessages(int limit) {
        List<ChatMessage> result = new ArrayList<>();
        int safeLimit = Math.max(1, Math.min(limit, 2000));
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id, role, content, created_at FROM (SELECT id, role, content, created_at FROM messages ORDER BY id DESC LIMIT ?) ORDER BY id ASC",
                new String[]{String.valueOf(safeLimit)})) {
            while (cursor.moveToNext()) {
                result.add(new ChatMessage(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getLong(3)));
            }
        }
        return result;
    }

    public synchronized long countMessages() {
        try (Cursor cursor = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM messages", null)) {
            return cursor.moveToFirst() ? cursor.getLong(0) : 0L;
        }
    }

    public synchronized long saveMemory(String title, String content, String source, boolean verified) {
        ContentValues values = new ContentValues();
        values.put("title", title == null || title.trim().isEmpty() ? "Kayıtlı bilgi" : title.trim());
        values.put("content", content == null ? "" : content.trim());
        values.put("source", source == null ? "kullanıcı" : source);
        values.put("verified", verified ? 1 : 0);
        values.put("updated_at", System.currentTimeMillis());
        return getWritableDatabase().insert("memories", null, values);
    }

    public synchronized List<MemoryEntry> searchMemories(String query, int limit) {
        List<MemoryEntry> result = new ArrayList<>();
        String clean = query == null ? "" : query.trim();
        if (clean.isEmpty()) {
            return result;
        }
        String[] words = clean.split("\\s+");
        StringBuilder where = new StringBuilder();
        ArrayList<String> args = new ArrayList<>();
        int accepted = 0;
        for (String word : words) {
            String token = word.replaceAll("[^\\p{L}\\p{N}]", "");
            if (token.length() < 2 || accepted >= 8) continue;
            if (where.length() > 0) where.append(" OR ");
            where.append("title LIKE ? OR content LIKE ?");
            String pattern = "%" + token + "%";
            args.add(pattern);
            args.add(pattern);
            accepted++;
        }
        if (where.length() == 0) return result;
        args.add(String.valueOf(Math.max(1, Math.min(limit, 100))));
        String sql = "SELECT id,title,content,source,verified,updated_at FROM memories WHERE " + where + " ORDER BY updated_at DESC LIMIT ?";
        try (Cursor cursor = getReadableDatabase().rawQuery(sql, args.toArray(new String[0]))) {
            while (cursor.moveToNext()) {
                result.add(new MemoryEntry(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getInt(4) == 1, cursor.getLong(5)));
            }
        }
        return result;
    }

    public synchronized List<MemoryEntry> getRecentMemories(int limit) {
        List<MemoryEntry> result = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id,title,content,source,verified,updated_at FROM memories ORDER BY updated_at DESC LIMIT ?",
                new String[]{String.valueOf(Math.max(1, Math.min(limit, 100)))})) {
            while (cursor.moveToNext()) {
                result.add(new MemoryEntry(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getInt(4) == 1, cursor.getLong(5)));
            }
        }
        return result;
    }

    public synchronized long saveTask(String title, String kind, String status, String details) {
        ContentValues values = new ContentValues();
        values.put("title", title == null ? "İsimsiz görev" : title.trim());
        values.put("kind", kind == null ? "genel" : kind);
        values.put("status", status == null ? "Bekliyor" : status);
        values.put("details", details == null ? "" : details);
        values.put("updated_at", System.currentTimeMillis());
        return getWritableDatabase().insert("tasks", null, values);
    }

    public synchronized List<TaskRecord> getRecentTasks(int limit) {
        List<TaskRecord> result = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id,title,kind,status,details,updated_at FROM tasks ORDER BY updated_at DESC LIMIT ?",
                new String[]{String.valueOf(Math.max(1, Math.min(limit, 200)))})) {
            while (cursor.moveToNext()) {
                result.add(new TaskRecord(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getLong(5)));
            }
        }
        return result;
    }

    public synchronized void saveTrainingExample(String text, String label) {
        ContentValues values = new ContentValues();
        values.put("text", text);
        values.put("label", label);
        values.put("created_at", System.currentTimeMillis());
        getWritableDatabase().insert("training_examples", null, values);
    }

    public synchronized List<String[]> getTrainingExamples() {
        List<String[]> result = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().rawQuery("SELECT text,label FROM training_examples ORDER BY id ASC", null)) {
            while (cursor.moveToNext()) result.add(new String[]{cursor.getString(0), cursor.getString(1)});
        }
        return result;
    }
}
