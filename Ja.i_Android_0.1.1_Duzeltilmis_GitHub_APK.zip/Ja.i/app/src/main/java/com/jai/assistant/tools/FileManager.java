package com.jai.assistant.tools;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Mobil dosya seçicisinden gelen metin tabanlı dosyaları güvenli sınırlarda okur/yazar. */
public final class FileManager {
    private static final int MAX_TEXT_BYTES = 1024 * 1024;

    public String getDisplayName(Context context, Uri uri) {
        try (Cursor cursor = context.getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {
            // Sağlayıcı görünen dosya adını vermeyebilir; aşağıda yedek ad kullanılır.
        }
        String segment = uri == null ? null : uri.getLastPathSegment();
        return segment == null ? "ek_dosya" : segment;
    }

    public String readText(Context context, Uri uri) throws IOException {
        if (uri == null) throw new IOException("Dosya seçilmedi.");
        ContentResolver resolver = context.getContentResolver();
        String name = getDisplayName(context, uri).toLowerCase(Locale.ROOT);
        String mime = resolver.getType(uri);
        if (!isSupportedText(name, mime)) {
            throw new IOException("Bu ilk sürüm yalnızca TXT, Markdown, Java, XML, JSON, Gradle, CSS, JS, Python ve benzeri metin dosyalarını okuyabilir. Görsel/PDF/ZIP içeriği henüz analiz edilmiyor.");
        }
        try (InputStream in = resolver.openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new IOException("Dosya açılamadı.");
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = in.read(buffer)) != -1) {
                total += read;
                if (total > MAX_TEXT_BYTES) throw new IOException("Dosya 1 MiB sınırını aşıyor; daha küçük bir metin dosyası seç.");
                out.write(buffer, 0, read);
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    public void writeText(ContentResolver resolver, Uri destination, String contents) throws IOException {
        if (destination == null) throw new IOException("Kayıt konumu seçilmedi.");
        try (OutputStream output = resolver.openOutputStream(destination, "wt")) {
            if (output == null) throw new IOException("Seçilen dosya konumu açılamadı.");
            output.write((contents == null ? "" : contents).getBytes(StandardCharsets.UTF_8));
            output.flush();
        }
    }

    private boolean isSupportedText(String name, String mime) {
        if (mime != null && (mime.startsWith("text/") || mime.equals("application/json") || mime.equals("application/xml") || mime.equals("application/javascript"))) return true;
        String[] extensions = {".txt", ".md", ".markdown", ".java", ".xml", ".json", ".gradle", ".properties", ".js", ".css", ".html", ".py", ".kt", ".yml", ".yaml", ".csv", ".log"};
        for (String extension : extensions) if (name.endsWith(extension)) return true;
        return false;
    }
}
