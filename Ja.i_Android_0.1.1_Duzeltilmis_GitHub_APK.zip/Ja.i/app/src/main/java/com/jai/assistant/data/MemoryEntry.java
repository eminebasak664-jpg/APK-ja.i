package com.jai.assistant.data;

public final class MemoryEntry {
    public final long id;
    public final String title;
    public final String content;
    public final String source;
    public final boolean verified;
    public final long updatedAt;

    public MemoryEntry(long id, String title, String content, String source, boolean verified, long updatedAt) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.source = source;
        this.verified = verified;
        this.updatedAt = updatedAt;
    }
}
