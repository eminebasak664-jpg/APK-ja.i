package com.jai.assistant;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.jai.assistant.data.ChatMessage;
import com.jai.assistant.data.ConversationManager;
import com.jai.assistant.data.MemoryDatabase;
import com.jai.assistant.data.SettingsManager;
import com.jai.assistant.engine.BrainEngine;
import com.jai.assistant.tools.FileManager;
import com.jai.assistant.tools.WebResearchEngine;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;

/** Android yerel sohbet arayüzü. Ağ işlemleri ana UI iş parçacığında yapılmaz. */
public final class MainActivity extends Activity {
    private static final int REQUEST_OPEN_TEXT_FILE = 4101;
    private static final int REQUEST_EXPORT_CHAT = 4102;
    private static final int MAX_RENDERED_MESSAGES = 250;

    private MemoryDatabase database;
    private ConversationManager conversations;
    private SettingsManager settings;
    private BrainEngine brain;
    private WebResearchEngine webResearch;
    private FileManager fileManager;
    private ExecutorService worker;

    private TextView subtitleText;
    private TextView statusText;
    private LinearLayout chatContainer;
    private ScrollView chatScroll;
    private EditText messageInput;
    private Button sendButton;
    private Spinner modeSpinner;
    private Spinner effortSpinner;
    private CheckBox webCheckBox;

    private String attachedText;
    private String attachedName;
    private volatile boolean activityDestroyed;
    private volatile boolean backgroundTaskRunning;
    private final AtomicBoolean databaseClosed = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = new MemoryDatabase(this);
        conversations = new ConversationManager(database);
        settings = new SettingsManager(this);
        brain = new BrainEngine(this, database);
        webResearch = new WebResearchEngine();
        fileManager = new FileManager();
        worker = Executors.newSingleThreadExecutor();

        bindViews();
        configureSpinners();
        restoreSettings();
        configureActions();

        if (database.countMessages() == 0) {
            conversations.add("assistant", "Merhaba, ben Ja.i. Bu ilk sürüm yerel sohbet geçmişi, not hafızası, basit hesaplama, kalıcı öğrenme görevleri ve Ara açıldığında web arama sonuçları sunar. Genel amaçlı dil modeli henüz yok; yapılmayan işlemleri yapılmış gibi göstermeyeceğim.");
        }
        reloadChat();
        updateConnectionLabel();
    }

    private void bindViews() {
        subtitleText = findViewById(R.id.subtitleText);
        statusText = findViewById(R.id.statusText);
        chatContainer = findViewById(R.id.chatContainer);
        chatScroll = findViewById(R.id.chatScroll);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);
        modeSpinner = findViewById(R.id.modeSpinner);
        effortSpinner = findViewById(R.id.effortSpinner);
        webCheckBox = findViewById(R.id.webCheckBox);
    }

    private void configureSpinners() {
        ArrayAdapter<String> modeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[]{"Flash", "Think"});
        modeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modeSpinner.setAdapter(modeAdapter);

        ArrayAdapter<String> effortAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[]{"Hızlı", "Orta", "Maksimum", "Derin"});
        effortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        effortSpinner.setAdapter(effortAdapter);
    }

    private void restoreSettings() {
        setSpinnerSelection(modeSpinner, settings.getMode());
        setSpinnerSelection(effortSpinner, settings.getEffort());
        webCheckBox.setChecked(settings.isWebResearchEnabled());
    }

    private void setSpinnerSelection(Spinner spinner, String wanted) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (String.valueOf(spinner.getItemAtPosition(i)).equals(wanted)) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    private void configureActions() {
        sendButton.setOnClickListener(view -> submitMessage());
        findViewById(R.id.attachButton).setOnClickListener(view -> openTextPicker());
        findViewById(R.id.exportButton).setOnClickListener(view -> exportChat());

        modeSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(value -> settings.setMode(value)));
        effortSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(value -> settings.setEffort(value)));
        webCheckBox.setOnCheckedChangeListener((buttonView, checked) -> {
            settings.setWebResearchEnabled(checked);
            statusText.setText(checked
                    ? "Ara açık: web isteği yalnızca mesaj gönderdiğinde ve uygunsa yapılır."
                    : "Ara kapalı: web araştırması başlatılmaz.");
        });

        messageInput.setOnEditorActionListener((view, actionId, event) -> {
            boolean send = actionId == EditorInfo.IME_ACTION_SEND
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP);
            if (send) {
                submitMessage();
                return true;
            }
            return false;
        });
    }

    private void submitMessage() {
        String typed = messageInput.getText().toString().trim();
        if (typed.isEmpty() && TextUtils.isEmpty(attachedText)) {
            Toast.makeText(this, "Önce bir mesaj yaz veya metin dosyası ekle.", Toast.LENGTH_SHORT).show();
            return;
        }

        String query = typed;
        if (!TextUtils.isEmpty(attachedText)) {
            String attachmentBlock = "\n\n[Metin eki: " + attachedName + "]\n" + attachedText;
            query = query + attachmentBlock;
        }
        messageInput.setText("");
        attachedText = null;
        attachedName = null;
        hideKeyboard();

        conversations.add("user", query);
        reloadChat();
        sendButton.setEnabled(false);
        String selectedMode = String.valueOf(modeSpinner.getSelectedItem());
        String selectedEffort = String.valueOf(effortSpinner.getSelectedItem());
        boolean webEnabled = webCheckBox.isChecked();
        statusText.setText("Yerel görev yürütülüyor…");

        final String finalQuery = query;
        final boolean researchNeeded = webEnabled && brain.shouldResearch(typed);
        backgroundTaskRunning = true;
        try {
            worker.execute(() -> {
                String answer;
                boolean networkAvailable = false;
                try {
                    answer = brain.answer(finalQuery, selectedMode, selectedEffort);
                    if (researchNeeded) {
                        networkAvailable = isNetworkAvailable();
                        if (networkAvailable) {
                            int resultCount = "Derin".equals(selectedEffort) ? 8
                                    : "Maksimum".equals(selectedEffort) ? 6
                                    : "Hızlı".equals(selectedEffort) ? 3 : 5;
                            answer += "\n\n" + webResearch.research(typed, resultCount);
                        } else {
                            answer += "\n\nAra açık ancak bu cihazda kullanılabilir internet bağlantısı görünmüyor. Web araması yapılmadı.";
                        }
                    }
                } catch (Exception exception) {
                    answer = "İşlem sırasında hata oluştu: " + safeMessage(exception)
                            + "\n\nMesajın tamamı Ja.i tarafından başarıyla işlenmiş sayılmaz.";
                }

                try {
                    conversations.add("assistant", answer);
                } catch (Exception persistenceException) {
                    answer += "\n\nUyarı: Yanıt sohbet veritabanına kaydedilemedi ("
                            + safeMessage(persistenceException) + ").";
                } finally {
                    backgroundTaskRunning = false;
                    if (activityDestroyed) closeDatabaseIfNeeded();
                }

                if (!activityDestroyed) {
                    final boolean finalNetworkAvailable = networkAvailable;
                    runOnUiThread(() -> {
                        if (activityDestroyed) return;
                        reloadChat();
                        sendButton.setEnabled(true);
                        updateConnectionLabel();
                        if (researchNeeded) {
                            statusText.setText(finalNetworkAvailable
                                    ? "İşlem tamamlandı · web arama denemesi yapıldı"
                                    : "İşlem tamamlandı · çevrimdışı");
                        } else {
                            statusText.setText("İşlem tamamlandı · yerel yanıt");
                        }
                    });
                }
            });
        } catch (RejectedExecutionException exception) {
            backgroundTaskRunning = false;
            sendButton.setEnabled(true);
            statusText.setText("Görev kuyruğu kapalı olduğu için mesaj başlatılamadı.");
        }
    }

    private void openTextPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_OPEN_TEXT_FILE);
    }

    private void exportChat() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "ja-i-sohbet.txt");
        startActivityForResult(intent, REQUEST_EXPORT_CHAT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQUEST_OPEN_TEXT_FILE) {
            try {
                attachedName = fileManager.getDisplayName(this, uri);
                attachedText = fileManager.readText(this, uri);
                statusText.setText("Metin eki hazır: " + attachedName + " (Gönder'e basınca mesajla birlikte işlenir.)");
                Toast.makeText(this, "Metin dosyası eklendi: " + attachedName, Toast.LENGTH_SHORT).show();
            } catch (IOException exception) {
                attachedText = null;
                attachedName = null;
                Toast.makeText(this, exception.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_EXPORT_CHAT) {
            try {
                fileManager.writeText(getContentResolver(), uri, conversations.exportPlainText());
                Toast.makeText(this, "Sohbet seçtiğin konuma aktarıldı.", Toast.LENGTH_LONG).show();
            } catch (IOException exception) {
                Toast.makeText(this, "Dışa aktarma başarısız: " + exception.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void reloadChat() {
        chatContainer.removeAllViews();
        List<ChatMessage> messages = conversations.recent(MAX_RENDERED_MESSAGES);
        for (ChatMessage message : messages) addMessageBubble(message.role, message.content);
        chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void addMessageBubble(String role, String content) {
        boolean user = "user".equals(role);
        TextView bubble = new TextView(this);
        bubble.setText(content);
        bubble.setTextColor(getResources().getColor(R.color.jai_text));
        bubble.setTextSize(15);
        bubble.setLineSpacing(dp(2), 1.0f);
        bubble.setTextIsSelectable(true);
        bubble.setAutoLinkMask(android.text.util.Linkify.WEB_URLS);
        bubble.setMovementMethod(LinkMovementMethod.getInstance());
        bubble.setPadding(dp(13), dp(10), dp(13), dp(10));

        GradientDrawable background = new GradientDrawable();
        background.setColor(getResources().getColor(user ? R.color.jai_user_bubble : R.color.jai_ai_bubble));
        background.setCornerRadius(dp(15));
        if (!user) background.setStroke(dp(1), getResources().getColor(R.color.jai_border));
        bubble.setBackground(background);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                Math.min((int) (getResources().getDisplayMetrics().widthPixels * 0.86f), dp(520)),
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = user ? Gravity.END : Gravity.START;
        params.setMargins(dp(4), dp(4), dp(4), dp(6));
        chatContainer.addView(bubble, params);
    }

    private void updateConnectionLabel() {
        boolean connected = isNetworkAvailable();
        subtitleText.setText(connected ? "Yerel asistan · ağ var" : "Yerel asistan · çevrimdışı");
        if (!webCheckBox.isChecked()) {
            statusText.setText(connected ? "Yerel sohbet hazır · Ara kapalı" : "Çevrimdışı yerel sohbet hazır");
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager == null) return false;
        Network network = manager.getActiveNetwork();
        if (network == null) return false;
        NetworkCapabilities capabilities = manager.getNetworkCapabilities(network);
        return capabilities != null
                && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
    }

    private String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.trim().isEmpty()
                ? exception.getClass().getSimpleName() : message;
    }

    private void closeDatabaseIfNeeded() {
        if (database != null && databaseClosed.compareAndSet(false, true)) {
            database.close();
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (manager != null) manager.hideSoftInputFromWindow(messageInput.getWindowToken(), 0);
        } catch (Exception ignored) {
            // Klavye görünmüyorsa mesaj gönderimi yine de sürer.
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        activityDestroyed = true;
        if (worker != null) worker.shutdown();
        if (!backgroundTaskRunning) closeDatabaseIfNeeded();
        super.onDestroy();
    }
}
