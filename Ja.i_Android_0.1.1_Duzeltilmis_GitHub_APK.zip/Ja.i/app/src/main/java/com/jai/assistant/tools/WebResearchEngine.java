package com.jai.assistant.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Haricî yapay zekâ kullanmadan HTML arama sonuçlarını okuyup kısa kaynak listesi döndürür. */
public final class WebResearchEngine {
    private static final String SEARCH_ENDPOINT = "https://html.duckduckgo.com/html/?q=";

    private static final class SearchResult {
        final String title;
        final String link;
        final String snippet;
        final int start;
        final int end;

        SearchResult(String title, String link, String snippet, int start, int end) {
            this.title = title;
            this.link = link;
            this.snippet = snippet;
            this.start = start;
            this.end = end;
        }
    }

    private static final class HtmlFragment {
        final int start;
        final int end;
        final String text;

        HtmlFragment(int start, int end, String text) {
            this.start = start;
            this.end = end;
            this.text = text;
        }
    }

    public String research(String query, int maxResults) {
        if (query == null || query.trim().isEmpty()) return "Web araştırması başlatılmadı: sorgu boş.";
        HttpURLConnection connection = null;
        try {
            URL url = URI.create(SEARCH_ENDPOINT + URLEncoder.encode(query.trim(), StandardCharsets.UTF_8.name())).toURL();
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(9000);
            connection.setReadTimeout(12000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "JaI-Android-Research/0.1 (user-initiated web search)");
            connection.setRequestProperty("Accept", "text/html,application/xhtml+xml");
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) {
                return "Web araştırması tamamlanamadı. Arama servisi HTTP " + status
                        + " yanıtı verdi. Yerel yanıt ayrı değerlendirilmelidir.";
            }

            String html;
            try (InputStream stream = connection.getInputStream()) {
                html = readLimited(stream, 1_200_000);
            }
            List<SearchResult> results = parseResults(html);
            int count = Math.max(1, Math.min(maxResults, 10));
            if (results.isEmpty()) {
                return "Web araştırması isteği gönderildi fakat arama sayfasından okunabilir sonuç çıkarılamadı. Bu, sorgunun sonuçsuz olduğunu kanıtlamaz.";
            }

            String searchedAt = DateFormat.getDateTimeInstance(
                    DateFormat.MEDIUM, DateFormat.SHORT, Locale.forLanguageTag("tr-TR")).format(new Date());
            StringBuilder output = new StringBuilder("Web arama sonuçları (DuckDuckGo):\n")
                    .append("Arama zamanı: ").append(searchedAt).append("\n")
                    .append("Not: Arama özetinde yayın tarihi verilmedi; aşağıdaki tarihler yayın tarihi değildir.\n");
            int shown = Math.min(count, results.size());
            for (int i = 0; i < shown; i++) {
                SearchResult result = results.get(i);
                output.append("\n").append(i + 1).append(". ").append(result.title).append("\n");
                if (!result.snippet.isEmpty()) output.append(result.snippet).append("\n");
                output.append(result.link).append("\n");
            }
            output.append("\nDoğrulama sınırı: Bu sürüm arama sayfasındaki başlıkları ve kısa özetleri aldı; bağlantıların tam sayfa içeriklerini okuyup bağımsız doğrulama yapmadı. Kaynakları açıp kontrol etmeden sonuçları kesin kabul etme.");
            return output.toString();
        } catch (IOException exception) {
            return "Web araştırması yapılamadı: bağlantı veya arama servisi hatası (" + safeMessage(exception)
                    + "). Ara açık olsa da bu deneme sonuç üretmedi; yerel yanıt internet araştırması değildir.";
        } catch (Exception exception) {
            return "Web araştırması beklenmeyen bir hatayla durdu: " + safeMessage(exception) + ".";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String readLimited(InputStream stream, int maxChars) throws IOException {
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                if (builder.length() + read > maxChars) throw new IOException("Arama yanıtı izin verilen boyutu aşıyor");
                builder.append(buffer, 0, read);
            }
        }
        return builder.toString();
    }

    private List<SearchResult> parseResults(String html) {
        List<HtmlFragment> anchors = new ArrayList<>();
        List<HtmlFragment> snippets = new ArrayList<>();

        Pattern anchorPattern = Pattern.compile("(?is)<a\\b([^>]*)>(.*?)</a>");
        Pattern classPattern = Pattern.compile("(?is)class\\s*=\\s*['\"]([^'\"]*)['\"]");
        Pattern hrefPattern = Pattern.compile("(?is)href\\s*=\\s*['\"]([^'\"]+)['\"]");
        Matcher anchorMatcher = anchorPattern.matcher(html);
        while (anchorMatcher.find() && anchors.size() < 20) {
            Matcher classMatcher = classPattern.matcher(anchorMatcher.group(1));
            if (!classMatcher.find() || !classMatcher.group(1).contains("result__a")) continue;
            Matcher hrefMatcher = hrefPattern.matcher(anchorMatcher.group(1));
            if (!hrefMatcher.find()) continue;
            String title = cleanHtml(anchorMatcher.group(2));
            String link = unwrapLink(decodeHtml(hrefMatcher.group(1)));
            if (title.isEmpty() || !isHttpUrl(link)) continue;
            anchors.add(new HtmlFragment(anchorMatcher.start(), anchorMatcher.end(), title + "\n" + link));
        }

        Pattern snippetPattern = Pattern.compile("(?is)<(?:a|div|td)\\b([^>]*)>(.*?)</(?:a|div|td)>");
        Matcher snippetMatcher = snippetPattern.matcher(html);
        while (snippetMatcher.find() && snippets.size() < 30) {
            Matcher classMatcher = classPattern.matcher(snippetMatcher.group(1));
            if (!classMatcher.find() || !classMatcher.group(1).contains("result__snippet")) continue;
            String snippet = cleanHtml(snippetMatcher.group(2));
            if (!snippet.isEmpty()) snippets.add(new HtmlFragment(snippetMatcher.start(), snippetMatcher.end(), snippet));
        }

        List<SearchResult> results = new ArrayList<>();
        for (int i = 0; i < anchors.size(); i++) {
            HtmlFragment anchor = anchors.get(i);
            int nextAnchorStart = i + 1 < anchors.size() ? anchors.get(i + 1).start : Integer.MAX_VALUE;
            String snippet = "";
            for (HtmlFragment candidate : snippets) {
                if (candidate.start >= anchor.end && candidate.start < nextAnchorStart) {
                    snippet = candidate.text;
                    break;
                }
            }
            String[] parts = anchor.text.split("\\n", 2);
            results.add(new SearchResult(parts[0], parts.length > 1 ? parts[1] : "", snippet,
                    anchor.start, anchor.end));
        }
        return results;
    }

    private boolean isHttpUrl(String link) {
        if (link == null) return false;
        String value = link.toLowerCase(Locale.ROOT);
        return value.startsWith("https://") || value.startsWith("http://");
    }

    private String unwrapLink(String link) {
        if (link != null && link.startsWith("//")) link = "https:" + link;
        try {
            URL url = URI.create(link).toURL();
            if (url.getHost().toLowerCase(Locale.ROOT).contains("duckduckgo.com") && url.getPath().contains("/l/")) {
                String query = url.getQuery();
                if (query != null) {
                    for (String item : query.split("&")) {
                        if (item.startsWith("uddg=")) {
                            return URLDecoder.decode(item.substring(5), StandardCharsets.UTF_8.name());
                        }
                    }
                }
            }
        } catch (Exception ignored) {
            // Geçersiz bağlantı daha sonra HTTP/HTTPS kontrolünden elenir.
        }
        return link;
    }

    private String cleanHtml(String text) {
        String decoded = decodeHtml(text).replaceAll("(?is)<script[^>]*>.*?</script>", " ")
                .replaceAll("(?is)<style[^>]*>.*?</style>", " ")
                .replaceAll("(?s)<[^>]+>", " ");
        return decoded.replaceAll("\\s+", " ").trim();
    }

    private String decodeHtml(String text) {
        return text.replace("&amp;", "&").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&apos;", "'")
                .replace("&lt;", "<").replace("&gt;", ">")
                .replace("&nbsp;", " ");
    }

    private String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.trim().isEmpty() ? exception.getClass().getSimpleName() : message;
    }
}
