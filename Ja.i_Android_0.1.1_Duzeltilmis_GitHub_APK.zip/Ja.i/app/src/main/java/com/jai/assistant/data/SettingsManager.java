package com.jai.assistant.data;

import android.content.Context;
import android.content.SharedPreferences;

public final class SettingsManager {
    private final SharedPreferences preferences;

    public SettingsManager(Context context) {
        preferences = context.getApplicationContext().getSharedPreferences("jai_settings", Context.MODE_PRIVATE);
    }

    public boolean isWebResearchEnabled() {
        return preferences.getBoolean("web_research_enabled", false);
    }

    public void setWebResearchEnabled(boolean enabled) {
        preferences.edit().putBoolean("web_research_enabled", enabled).apply();
    }

    public String getMode() {
        return preferences.getString("mode", "Flash");
    }

    public void setMode(String mode) {
        preferences.edit().putString("mode", mode).apply();
    }

    public String getEffort() {
        return preferences.getString("effort", "Orta");
    }

    public void setEffort(String effort) {
        preferences.edit().putString("effort", effort).apply();
    }
}
