package com.jai.assistant.engine;

import com.jai.assistant.data.MemoryDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Çok küçük bir kelime-temelli Naive Bayes amaç sınıflandırıcısıdır.
 * Genel amaçlı dil modeli değildir. Yerleşik etiketli örneklerle başlar ve
 * açıkça verilen yeni örnekleri yerel veritabanına kaydedip yeniden eğitilebilir.
 */
public final class ModelEngine {
    private static final String[] LABELS = {"selam", "matematik", "hafiza", "kod", "ogrenme", "zaman", "genel"};
    private final MemoryDatabase database;
    private final Map<String, Map<String, Integer>> wordsByLabel = new HashMap<>();
    private final Map<String, Integer> wordTotals = new HashMap<>();
    private final Map<String, Integer> documentTotals = new HashMap<>();
    private final Set<String> vocabulary = new HashSet<>();
    private int totalDocuments;

    public ModelEngine(MemoryDatabase database) {
        this.database = database;
        rebuild();
    }

    public synchronized String classify(String text) {
        List<String> tokens = tokenize(text);
        if (tokens.isEmpty()) return "genel";
        String bestLabel = "genel";
        double bestScore = Double.NEGATIVE_INFINITY;
        for (String label : LABELS) {
            int labelDocs = documentTotals.containsKey(label) ? documentTotals.get(label) : 0;
            double score = Math.log((labelDocs + 1.0) / (totalDocuments + LABELS.length));
            Map<String, Integer> counts = wordsByLabel.get(label);
            int totalWords = wordTotals.containsKey(label) ? wordTotals.get(label) : 0;
            for (String token : tokens) {
                int tokenCount = counts != null && counts.containsKey(token) ? counts.get(token) : 0;
                score += Math.log((tokenCount + 1.0) / (totalWords + vocabulary.size() + 1.0));
            }
            if (score > bestScore) {
                bestScore = score;
                bestLabel = label;
            }
        }
        return bestLabel;
    }

    public synchronized boolean learnExample(String text, String label) {
        if (text == null || text.trim().length() < 2 || !isKnownLabel(label)) return false;
        database.saveTrainingExample(text.trim(), label);
        rebuild();
        return true;
    }

    public boolean isKnownLabel(String label) {
        if (label == null) return false;
        for (String item : LABELS) if (item.equals(label.trim().toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    public List<String> knownLabels() {
        return new ArrayList<>(Arrays.asList(LABELS));
    }

    private synchronized void rebuild() {
        wordsByLabel.clear();
        wordTotals.clear();
        documentTotals.clear();
        vocabulary.clear();
        totalDocuments = 0;

        List<String[]> examples = new ArrayList<>();
        examples.add(new String[]{"merhaba selam günaydın iyi akşamlar", "selam"});
        examples.add(new String[]{"selam ja.i nasılsın ne haber", "selam"});
        examples.add(new String[]{"2 + 2 kaç eder hesapla 15/3", "matematik"});
        examples.add(new String[]{"bir sayı işleminin sonucunu bul", "matematik"});
        examples.add(new String[]{"bunu hatırla hafızaya kaydet daha önce ne demiştim", "hafiza"});
        examples.add(new String[]{"hafızada ara kaydettiğim bilgiyi bul", "hafiza"});
        examples.add(new String[]{"java kod yaz program hata ayıkla derle", "kod"});
        examples.add(new String[]{"bu kodu kontrol et uygulama oluştur", "kod"});
        examples.add(new String[]{"çince öğren java öğren konu öğret", "ogrenme"});
        examples.add(new String[]{"öğrenme kuyruğuna konu ekle çalışmayı başlat", "ogrenme"});
        examples.add(new String[]{"saat kaç bugün tarih nedir", "zaman"});
        examples.add(new String[]{"şu an saat kaç tarih göster", "zaman"});
        examples.add(new String[]{"fotosentez nasıl olur açıklama istiyorum", "genel"});
        examples.add(new String[]{"bana bilgi ver bunu karşılaştır", "genel"});
        examples.add(new String[]{"neden nasıl ne demek anlat", "genel"});
        examples.addAll(database.getTrainingExamples());

        for (String[] example : examples) {
            if (example == null || example.length < 2 || !isKnownLabel(example[1])) continue;
            addTrainingRecord(example[0], example[1]);
        }
    }

    private void addTrainingRecord(String text, String label) {
        totalDocuments++;
        documentTotals.put(label, documentTotals.containsKey(label) ? documentTotals.get(label) + 1 : 1);
        Map<String, Integer> counts = wordsByLabel.get(label);
        if (counts == null) {
            counts = new HashMap<>();
            wordsByLabel.put(label, counts);
        }
        for (String token : tokenize(text)) {
            vocabulary.add(token);
            counts.put(token, counts.containsKey(token) ? counts.get(token) + 1 : 1);
            wordTotals.put(label, wordTotals.containsKey(label) ? wordTotals.get(label) + 1 : 1);
        }
    }

    private static List<String> tokenize(String text) {
        List<String> tokens = new ArrayList<>();
        if (text == null) return tokens;
        Matcher matcher = Pattern.compile("[\\p{L}\\p{N}]{2,}").matcher(text.toLowerCase(Locale.forLanguageTag("tr-TR")));
        while (matcher.find()) tokens.add(matcher.group());
        return tokens;
    }
}
