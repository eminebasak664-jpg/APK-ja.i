package com.jai.assistant.engine;

import com.jai.assistant.data.MemoryDatabase;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** Yerel istek sınıflandırma, küçük araç seçimi ve cevap birleştirme çekirdeği. */
public final class BrainEngine {
    private final MemoryDatabase database;
    private final ModelEngine modelEngine;
    private final LocalSearchEngine localSearchEngine;
    private final LearningEngine learningEngine;
    private final TaskPlanner taskPlanner;
    private final CodeLabEngine codeLabEngine;
    private final ResourceManager resourceManager;
    private final ToolRegistry tools;

    public BrainEngine(android.content.Context context, MemoryDatabase database) {
        this.database = database;
        this.modelEngine = new ModelEngine(database);
        this.localSearchEngine = new LocalSearchEngine(database);
        this.learningEngine = new LearningEngine(database);
        this.taskPlanner = new TaskPlanner();
        this.codeLabEngine = new CodeLabEngine();
        this.resourceManager = new ResourceManager(context);
        this.tools = new ToolRegistry();
        tools.register("calculator", expression -> formatNumber(ExpressionEvaluator.evaluate(expression)));
        tools.register("memory_search", query -> localSearchEngine.search(query, 8));
        tools.register("device_resources", ignored -> resourceManager.describe());
        tools.register("static_code_check", input -> {
            int newline = input.indexOf('\n');
            String language = newline < 0 ? "bilinmeyen dil" : input.substring(0, newline).trim();
            String code = newline < 0 ? input : input.substring(newline + 1);
            return codeLabEngine.analyze(code, language);
        });
    }

    public String answer(String prompt, String mode, String effort) {
        String text = prompt == null ? "" : prompt.trim();
        if (text.isEmpty()) return "Boş bir mesaj aldım. Bir soru veya görev yaz.";
        String lower = text.toLowerCase(Locale.forLanguageTag("tr-TR"));
        String label = modelEngine.classify(text);
        String answer;

        if (startsWithCommand(lower, "hatırla:", "hatirla:", "/hatırla ", "/hatirla ")) {
            String content = text.substring(text.indexOf(':') >= 0 ? text.indexOf(':') + 1 : firstSpace(text)).trim();
            if (content.isEmpty()) return "Kaydedilecek metin boş. 'hatırla: kaydetmek istediğin bilgi' biçimini kullan.";
            database.saveMemory("Kullanıcı notu", content, "kullanıcı tarafından girildi", false);
            answer = "Bilgiyi Ja.i'nin yerel hafızasına kaydettim. Bu işlem genel dil yeteneğimi eğitmez; yalnızca daha sonra aranabilecek bir kayıt oluşturur.";
        } else if (startsWithCommand(lower, "öğren:", "ogren:", "öğren ", "ogren ")) {
            String topic = text.replaceFirst("(?i)^(öğren|ogren)\\s*:?\\s*", "").trim();
            if (topic.isEmpty()) return "Öğrenme kuyruğuna eklemek için bir konu yaz: 'öğren: Java döngüleri'.";
            long id = learningEngine.enqueueTopic(topic);
            answer = "'" + topic + "' konusu yerel öğrenme kuyruğuna eklendi (görev #" + id + "). Bu sürüm görevi kalıcı olarak saklıyor; henüz arka planda otomatik araştırma veya genel dil modeli eğitimi yapmıyor.";
        } else if (lower.startsWith("öğret-intent:") || lower.startsWith("ogret-intent:")) {
            String body = text.substring(text.indexOf(':') + 1);
            int separator = body.indexOf('|');
            if (separator <= 0 || separator >= body.length() - 1) {
                answer = "Biçim: öğret-intent:etiket|örnek cümle. Etiketler: " + String.join(", ", modelEngine.knownLabels());
            } else {
                String intent = body.substring(0, separator).trim().toLowerCase(Locale.ROOT);
                String example = body.substring(separator + 1).trim();
                answer = modelEngine.learnExample(example, intent)
                        ? "Örnek yerel sınıflandırıcının eğitim kayıtlarına eklendi ve sınıflandırıcı yeniden kuruldu. Bu yalnızca istek türü sınıflandırmasını etkiler; genel dil üretimini öğretmez."
                        : "Örnek eklenmedi. Etiketi kontrol et: " + String.join(", ", modelEngine.knownLabels());
            }
        } else if (looksLikeMath(text)) {
            String expression = extractExpression(text);
            try {
                answer = expression + " = " + formatNumber(ExpressionEvaluator.evaluate(expression)) + "\n\nHesaplama yerel dört işlem ayrıştırıcısıyla yapıldı; dış servise gönderilmedi.";
            } catch (IllegalArgumentException exception) {
                answer = "Bu matematik ifadesini hesaplayamadım: " + exception.getMessage();
            }
        } else if (containsAny(lower, "saat kaç", "bugünün tarihi", "bugün tarih", "şu an saat", "tarih nedir")) {
            answer = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT, Locale.forLanguageTag("tr-TR")).format(new Date()) + " (telefonun yerel saati).";
        } else if (containsAny(lower, "hafızada ara", "hafizada ara", "ne hatırlıyorsun", "ne hatirliyorsun", "kaydettiğim", "kayitli hafiza", "yerel hafıza", "yerel hafiza")) {
            answer = toolsExecute("memory_search", extractMemorySearchQuery(text));
        } else if (containsAny(lower, "ram durum", "bellek durumu", "depolama durumu", "telefon kaynakları", "kaynak kullanım")) {
            answer = toolsExecute("device_resources", "");
        } else if (containsAny(lower, "kodu kontrol et", "kod hatası", "kod hatasi", "ayraç kontrol", "ayrac kontrol")) {
            String attachedCode = extractAttachedCode(text);
            if (attachedCode.isEmpty()) attachedCode = extractFencedCode(text);
            if (!attachedCode.isEmpty()) {
                String language = detectLanguage(text);
                answer = toolsExecute("static_code_check", language + "\n" + attachedCode);
            } else {
                answer = "Kodu statik kontrol edebilmem için metin tabanlı bir kaynak dosyası ekle veya mesajına ```java ... ``` gibi bir kod bloğu koy. Bu araç yalnızca basit ayraçları denetler; kodu derlemez ya da çalıştırmaz.";
            }
        } else if (containsAny(lower, "merhaba", "selam", "günaydın", "iyi akşamlar", "iyi aksamlar", "nasılsın", "naber") && label.equals("selam")) {
            answer = "Merhaba! Ben Ja.i. Bu başlangıç sürümü yerel hafıza, basit hesaplama, kalıcı sohbet ve isteğe bağlı web arama sonuçlarını destekliyor. Genel amaçlı dil modeli henüz bulunmuyor; bu yüzden kapsamlı sorularda sınırlarımı açıkça belirteceğim.";
        } else if (containsAny(lower, "ne yapabiliyorsun", "özelliklerin neler", "ozelliklerin neler", "yardım", "yardim")) {
            answer = "Bu ilk sürümde çalışan temel özellikler: sohbet geçmişini yerel SQLite veritabanında tutma, 'hatırla:' ile not kaydetme, hafızada arama, basit dört işlem, 'öğren:' ile kalıcı görev kuyruğu, Think için görev özeti, metin dosyası içe/dışa aktarma ve Ara açıkken arama sonuçlarını alma.\n\nHenüz tamamlanmayanlar: genel amaçlı dil modeli, otomatik konu eğitimi, APK derleme, genel kod üretimi/çalıştırma, görsel-video üretimi ve gerçek kullanıcılar arası mesajlaşma sunucusu.";
        } else if (label.equals("kod")) {
            answer = "Kodlama isteğini sınıflandırdım; ancak bu ilk sürümde genel amaçlı kod üretimi ve kod çalıştırma motoru henüz tamamlanmadı. Kod dosyalarını metin olarak içe aktarabilirsin; bu sürümün dosya okuyucusu yalnızca desteklenen metin dosyalarını okur. Çalıştırma veya derleme yapılmış gibi davranmayacağım.";
        } else {
            answer = "Bu sürümde genel amaçlı bir büyük dil modeli yok. Yerel amaç sınıflandırıcısı isteğini '" + label + "' olarak sınıflandırdı, ancak tek başına bu sınıflandırma sorunun cevabını bildiğim anlamına gelmez. Ara kapalıysa internetten araştırma yapmadım. Araçlarımın desteklemediği bir bilgiyi uydurmak yerine bunu belirtmem gerekir.";
        }

        if ("Think".equalsIgnoreCase(mode)) {
            List<String> plan = taskPlanner.createPlan(text, effort);
            StringBuilder builder = new StringBuilder(answer).append("\n\nİşlem özeti (Think / ").append(effort).append("):");
            for (String step : plan) builder.append("\n• ").append(step);
            return builder.toString();
        }
        return answer;
    }

    public boolean shouldResearch(String prompt) {
        String text = prompt == null ? "" : prompt.trim().toLowerCase(Locale.forLanguageTag("tr-TR"));
        if (text.length() < 5) return false;
        if (containsAny(text, "hatırla:", "hatirla:", "hafızada ara", "hafizada ara", "saat kaç", "bugün tarih", "hesapla:", "kodu kontrol et", "öğret-intent:", "ogret-intent:")) return false;
        if (looksLikeMath(text)) return false;
        if (containsAny(text, "merhaba", "selam", "günaydın", "nasılsın", "naber")) return false;
        return true;
    }

    public String getRegisteredToolSummary() {
        StringBuilder builder = new StringBuilder("Kayıtlı yerel araçlar:");
        for (Map.Entry<String, ToolRegistry.Tool> entry : tools.registeredTools().entrySet()) {
            builder.append("\n• ").append(entry.getKey());
        }
        return builder.toString();
    }


    private String extractMemorySearchQuery(String text) {
        String query = text == null ? "" : text.trim();
        String lower = query.toLowerCase(Locale.forLanguageTag("tr-TR"));
        String[] prefixes = {"hafızada ara", "hafizada ara"};
        for (String prefix : prefixes) {
            if (lower.startsWith(prefix)) {
                return query.substring(prefix.length()).trim();
            }
        }
        if (containsAny(lower, "ne hatırlıyorsun", "ne hatirliyorsun", "yerel hafıza", "yerel hafiza", "kayıtlı hafıza", "kayitli hafiza")) {
            return "";
        }
        return query;
    }

    private String extractAttachedCode(String text) {
        int marker = text.indexOf("[Metin eki:");
        if (marker < 0) return "";
        int firstLine = text.indexOf('\n', marker);
        if (firstLine < 0 || firstLine + 1 >= text.length()) return "";
        return text.substring(firstLine + 1).trim();
    }

    private String extractFencedCode(String text) {
        int opening = text.indexOf("```");
        if (opening < 0) return "";
        int contentStart = text.indexOf('\n', opening);
        int closing = text.indexOf("```", contentStart < 0 ? opening + 3 : contentStart + 1);
        if (contentStart < 0 || closing < 0 || closing <= contentStart) return "";
        return text.substring(contentStart + 1, closing).trim();
    }

    private String detectLanguage(String text) {
        String lower = text.toLowerCase(Locale.forLanguageTag("tr-TR"));
        // Check JavaScript before Java so the shared "java" prefix cannot misclassify it.
        if (lower.contains("javascript") || lower.contains("```js") || lower.contains(".js")) return "JavaScript";
        if (lower.contains("```java") || lower.contains(".java") || lower.contains("java kod")) return "Java";
        if (lower.contains("```python") || lower.contains(".py") || lower.contains("python")) return "Python";
        if (lower.contains("```xml") || lower.contains(".xml")) return "XML";
        if (lower.contains("```html") || lower.contains(".html")) return "HTML";
        if (lower.contains(".css") || lower.contains("```css")) return "CSS";
        return "kaynak kod";
    }

    private String toolsExecute(String tool, String input) {
        try {
            return tools.execute(tool, input);
        } catch (Exception exception) {
            return "Yerel araç çalıştırılamadı: " + exception.getMessage();
        }
    }

    private boolean looksLikeMath(String text) {
        String expression = extractExpression(text);
        return expression.matches("[0-9\\s.,+*/()\\-]+") && Pattern.compile("[+*/\\-]").matcher(expression).find() && Pattern.compile("\\d").matcher(expression).find();
    }

    private String extractExpression(String text) {
        String candidate = text.trim();
        candidate = candidate.replaceAll("(?i)^(hesapla|sonuç|sonuc)\\s*[:：]?\\s*", "");
        candidate = candidate.replaceAll("(?i)\\s*(kaç eder|kac eder|kaçtır|kactir)\\??\\s*$", "");
        candidate = candidate.replaceAll("=\\s*$", "").replace("?", "").trim();
        return candidate;
    }

    private boolean startsWithCommand(String lower, String... prefixes) {
        for (String prefix : prefixes) if (lower.startsWith(prefix)) return true;
        return false;
    }

    private int firstSpace(String value) {
        int index = value.indexOf(' ');
        return index < 0 ? value.length() : index;
    }

    private boolean containsAny(String text, String... fragments) {
        for (String fragment : fragments) if (text.contains(fragment)) return true;
        return false;
    }

    private String formatNumber(double value) {
        if (Math.abs(value - Math.rint(value)) < 1e-10 && Math.abs(value) < 9e15) return String.format(Locale.ROOT, "%.0f", value);
        return String.format(Locale.ROOT, "%.8f", value).replaceAll("0+$", "").replaceAll("\\.$", "");
    }
}
