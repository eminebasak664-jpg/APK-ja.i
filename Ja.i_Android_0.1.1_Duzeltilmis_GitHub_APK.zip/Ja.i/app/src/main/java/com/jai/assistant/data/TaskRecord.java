package com.jai.assistant.data;

public final class TaskRecord {
    public final long id;
    public final String title;
    public final String kind;
    public final String status;
    public final String details;
    public final long updatedAt;

    public TaskRecord(long id, String title, String kind, String status, String details, long updatedAt) {
        this.id = id;
        this.title = title;
        this.kind = kind;
        this.status = status;
        this.details = details;
        this.updatedAt = updatedAt;
    }
}
