package com.jai.assistant;

import android.view.View;
import android.widget.AdapterView;

import java.util.function.Consumer;

/** Spinner değerlerini ayar deposuna aktarmak için küçük yardımcı. */
final class SimpleItemSelectedListener implements AdapterView.OnItemSelectedListener {
    private final Consumer<String> onSelected;

    SimpleItemSelectedListener(Consumer<String> onSelected) {
        this.onSelected = onSelected;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Object item = parent.getItemAtPosition(position);
        if (item != null && onSelected != null) onSelected.accept(item.toString());
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // Seçim kaldırılırsa ayar değiştirilmez.
    }
}
