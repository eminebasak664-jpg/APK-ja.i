package com.jai.assistant.engine;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;

/** Derleyici değildir: yorum ve dizgeleri atlayarak basit ayraç ön kontrolü yapar. */
public final class CodeLabEngine {
    public String analyze(String code, String language) {
        if (code == null || code.trim().isEmpty()) return "İncelenecek kod boş.";

        String lang = language == null ? "" : language.toLowerCase(Locale.ROOT);
        boolean pythonLike = lang.contains("python") || lang.contains("yaml") || lang.contains("shell");
        boolean xmlLike = lang.contains("xml") || lang.contains("html") || lang.contains("svg");
        Deque<Character> stack = new ArrayDeque<>();
        char quote = 0;
        boolean escaped = false;
        boolean tripleQuote = false;
        boolean lineComment = false;
        boolean blockComment = false;
        boolean xmlComment = false;
        int line = 1;

        for (int i = 0; i < code.length(); i++) {
            char c = code.charAt(i);
            char next = i + 1 < code.length() ? code.charAt(i + 1) : 0;
            char next2 = i + 2 < code.length() ? code.charAt(i + 2) : 0;

            if (c == '\n') line++;

            if (lineComment) {
                if (c == '\n') lineComment = false;
                continue;
            }
            if (blockComment) {
                if (c == '*' && next == '/') {
                    blockComment = false;
                    i++;
                }
                continue;
            }
            if (xmlComment) {
                if (c == '-' && next == '-' && next2 == '>') {
                    xmlComment = false;
                    i += 2;
                }
                continue;
            }

            if (quote != 0) {
                if (escaped) {
                    escaped = false;
                } else if (c == '\\') {
                    escaped = true;
                } else if (tripleQuote && c == quote && next == quote && next2 == quote) {
                    quote = 0;
                    tripleQuote = false;
                    i += 2;
                } else if (!tripleQuote && c == quote) {
                    quote = 0;
                }
                continue;
            }

            if (xmlLike && c == '<' && next == '!' && next2 == '-') {
                if (i + 3 < code.length() && code.charAt(i + 3) == '-') {
                    xmlComment = true;
                    i += 3;
                    continue;
                }
            }
            if (!pythonLike && !xmlLike && c == '/' && next == '/') {
                lineComment = true;
                i++;
                continue;
            }
            if (!pythonLike && !xmlLike && c == '/' && next == '*') {
                blockComment = true;
                i++;
                continue;
            }
            if (pythonLike && c == '#') {
                lineComment = true;
                continue;
            }

            if ((pythonLike || lang.equals("java")) && (c == '\'' || c == '"')
                    && next == c && next2 == c) {
                quote = c;
                tripleQuote = true;
                i += 2;
                continue;
            }
            if (c == '\'' || c == '"' || (c == '`' && !pythonLike && !xmlLike)) {
                quote = c;
                continue;
            }

            if (c == '{' || c == '(' || c == '[') {
                stack.push(c);
            } else if (c == '}' || c == ')' || c == ']') {
                if (stack.isEmpty()) {
                    return "Statik ön kontrol sonucu (" + safeLanguage(language) + "):\nSatır "
                            + line + " civarında eşleşmeyen kapatma karakteri '" + c + "'.\n"
                            + "Bu kontrol derleme veya çalıştırma testi değildir.";
                }
                char open = stack.pop();
                if (!matches(open, c)) {
                    return "Statik ön kontrol sonucu (" + safeLanguage(language) + "):\nSatır "
                            + line + " civarında '" + open + "' ve '" + c + "' eşleşmiyor.\n"
                            + "Bu kontrol derleme veya çalıştırma testi değildir.";
                }
            }
        }

        if (blockComment) {
            return "Statik ön kontrol: dosya sonunda kapanmamış bir /* yorum bloğu olabilir. Bu kontrol derleme veya çalıştırma testi değildir.";
        }
        if (xmlComment) {
            return "Statik ön kontrol: dosya sonunda kapanmamış bir XML/HTML yorum bloğu olabilir. Bu kontrol derleme veya çalıştırma testi değildir.";
        }
        if (quote != 0) {
            return "Statik ön kontrol: dosya sonunda kapanmamış bir dizge/tırnak olabilir. Bu kontrol derleme veya çalıştırma testi değildir.";
        }
        if (!stack.isEmpty()) {
            return "Statik ön kontrol: kapanmamış '" + stack.peek() + "' ayıracı var. Bu kontrol derleme veya çalıştırma testi değildir.";
        }
        return "Basit ayraç kontrolü geçti (" + safeLanguage(language) + "). Yorum ve dizgeler atlandı; bu, sözdiziminin tamamen doğru olduğunu kanıtlamaz. Kod derlenmedi veya çalıştırılmadı.";
    }

    private boolean matches(char open, char close) {
        return (open == '{' && close == '}') || (open == '(' && close == ')') || (open == '[' && close == ']');
    }

    private String safeLanguage(String language) {
        return language == null || language.trim().isEmpty() ? "bilinmeyen dil" : language.trim();
    }
}
