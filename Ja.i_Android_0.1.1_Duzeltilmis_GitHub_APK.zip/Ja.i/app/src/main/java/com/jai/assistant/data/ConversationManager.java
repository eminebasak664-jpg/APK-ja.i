package com.jai.assistant.data;

import java.util.List;

/** Sohbet geçmişi için DB arayüzü; görüntü katmanını veritabanı sorgularından ayırır. */
public final class ConversationManager {
    private final MemoryDatabase database;

    public ConversationManager(MemoryDatabase database) {
        this.database = database;
    }

    public long add(String role, String content) {
        return database.saveMessage(role, content);
    }

    public List<ChatMessage> recent(int limit) {
        return database.getRecentMessages(limit);
    }

    public String exportPlainText() {
        StringBuilder builder = new StringBuilder();
        for (ChatMessage message : database.getRecentMessages(2000)) {
            builder.append(message.role.equals("user") ? "Kullanıcı" : "Ja.i")
                    .append(" — ")
                    .append(message.content)
                    .append("\n\n");
        }
        return builder.toString();
    }
}
