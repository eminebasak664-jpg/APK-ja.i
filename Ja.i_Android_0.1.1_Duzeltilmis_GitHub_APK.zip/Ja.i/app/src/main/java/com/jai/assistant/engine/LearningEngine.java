package com.jai.assistant.engine;

import com.jai.assistant.data.MemoryDatabase;
import com.jai.assistant.data.TaskRecord;

import java.util.List;

/** Bu sürümde konu öğrenimini kalıcı kuyruğa alır; web'den otomatik eğitim iddiasında bulunmaz. */
public final class LearningEngine {
    private final MemoryDatabase database;

    public LearningEngine(MemoryDatabase database) {
        this.database = database;
    }

    public long enqueueTopic(String topic) {
        String cleaned = topic == null ? "" : topic.trim();
        if (cleaned.isEmpty()) throw new IllegalArgumentException("Öğrenilecek konu boş olamaz.");
        return database.saveTask(cleaned, "öğrenme", "Bekliyor", "Konu yerel görev kuyruğuna alındı. Otomatik web araştırması ve eğitim henüz uygulanmadı.");
    }

    public List<TaskRecord> recentTasks(int limit) {
        return database.getRecentTasks(limit);
    }
}
