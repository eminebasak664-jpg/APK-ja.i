package com.jai.assistant.engine;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Think modunda gösterilen ve görev kapsamına göre değişen uygulanabilir işlem planı. */
public final class TaskPlanner {
    public List<String> createPlan(String prompt, String effort) {
        String text = prompt == null ? "" : prompt.toLowerCase(Locale.forLanguageTag("tr-TR"));
        List<String> plan = new ArrayList<>();
        boolean code = containsAny(text, "kod", "java", "javascript", "oyun", "uygulama", "apk", "proje", "html");
        boolean research = containsAny(text, "araştır", "güncel", "kaynak", "haber", "bugün", "karşılaştır");
        boolean memory = containsAny(text, "hatırla", "hafıza", "kaydet", "öğren");

        plan.add("İsteği ve beklenen çıktıyı sınıflandır.");
        if (memory) plan.add("İlgili yerel hafıza ve kayıtlı görevleri ara.");
        else if (research) plan.add("Yerel kayıtları kontrol et; Ara açıksa web sonuçlarını iste.");
        else if (code) plan.add("Kod veya proje gereksinimlerini belirle; bu sürümde yalnızca desteklenen araçları kullan.");
        else plan.add("Yerel bağlamı ve kullanılabilir hesaplama/arama araçlarını kontrol et.");

        int extra = effortCount(effort);
        if (extra >= 2) plan.add("Sonuç için gerekli alt işlemleri sırala ve kullanılabilir araçları seç.");
        if (extra >= 3 && code) plan.add("Statik kontrolleri uygula; derleme/çalıştırma yapılmadıysa bunu ayrı belirt.");
        if (extra >= 3 && research) plan.add("Kaynak bağlantılarını ve arama sonucunun sınırlarını kaydet.");
        if (extra >= 4) plan.add("Eksik bilgi, çelişki ve hata olasılığını ayrıca denetle.");
        plan.add("Yanıtı mevcut doğrulama düzeyini ve eksikleri belirterek sun.");
        return plan;
    }

    private int effortCount(String effort) {
        if ("Hızlı".equals(effort)) return 1;
        if ("Orta".equals(effort)) return 2;
        if ("Maksimum".equals(effort)) return 3;
        return 4;
    }

    private boolean containsAny(String text, String... needles) {
        for (String needle : needles) if (text.contains(needle)) return true;
        return false;
    }
}
