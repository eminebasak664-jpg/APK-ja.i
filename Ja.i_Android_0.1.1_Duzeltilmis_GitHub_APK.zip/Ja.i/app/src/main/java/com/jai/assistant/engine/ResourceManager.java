package com.jai.assistant.engine;

import android.app.ActivityManager;
import android.content.Context;
import android.os.StatFs;

import java.io.File;
import java.util.Locale;

/** Cihaz kaynakları için yaklaşık durum; RAM'i rezerve etmez veya sınırsızmış gibi davranmaz. */
public final class ResourceManager {
    private final Context context;

    public ResourceManager(Context context) {
        this.context = context.getApplicationContext();
    }

    public String describe() {
        Runtime runtime = Runtime.getRuntime();
        long appMax = runtime.maxMemory();
        long appUsed = runtime.totalMemory() - runtime.freeMemory();
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) manager.getMemoryInfo(memoryInfo);
        File dataDir = context.getFilesDir();
        StatFs stat = new StatFs(dataDir.getAbsolutePath());
        long availableBytes = stat.getAvailableBytes();
        return String.format(Locale.getDefault(),
                "Uygulama belleği: yaklaşık %.0f / %.0f MiB kullanılıyor/izinli.\nCihazda kullanılabilir RAM: yaklaşık %.0f MiB.\nVeri bölümünde kullanılabilir alan: yaklaşık %.0f MiB.",
                appUsed / 1048576.0, appMax / 1048576.0, memoryInfo.availMem / 1048576.0, availableBytes / 1048576.0);
    }
}
