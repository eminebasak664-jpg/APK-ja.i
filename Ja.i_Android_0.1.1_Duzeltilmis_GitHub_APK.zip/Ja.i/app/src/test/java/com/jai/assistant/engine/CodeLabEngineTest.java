package com.jai.assistant.engine;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public final class CodeLabEngineTest {
    private final CodeLabEngine engine = new CodeLabEngine();

    @Test
    public void ignoresBracketsInsideJavaCommentsAndStrings() {
        String code = "class Demo { // } ]\n String value = \"{ not code }\"; /* [ ( */ void run() { } }";
        String result = engine.analyze(code, "Java");
        assertTrue(result, result.contains("ayraç kontrolü geçti"));
    }

    @Test
    public void ignoresBracketsInsidePythonComments() {
        String result = engine.analyze("def run():\n    value = [1, 2]  # } ]\n    return value", "Python");
        assertTrue(result, result.contains("ayraç kontrolü geçti"));
    }

    @Test
    public void detectsRealMismatchedBrackets() {
        String result = engine.analyze("function x() { return (1]; }", "JavaScript");
        assertTrue(result, result.contains("eşleşmiyor"));
    }

    @Test
    public void ignoresBracketsInsidePythonTripleQuotedStrings() {
        String result = engine.analyze("value = \"\"\" ] } ) not code \"\"\"\nprint(value)", "Python");
        assertTrue(result, result.contains("ayraç kontrolü geçti"));
    }

    @Test
    public void detectsUnclosedBlockComment() {
        String result = engine.analyze("class A { /* unfinished", "Java");
        assertTrue(result, result.contains("kapanmamış"));
    }
}
