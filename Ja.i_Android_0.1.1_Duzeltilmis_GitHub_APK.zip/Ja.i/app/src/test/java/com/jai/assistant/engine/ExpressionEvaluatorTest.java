package com.jai.assistant.engine;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public final class ExpressionEvaluatorTest {
    @Test
    public void followsOperatorPrecedence() {
        assertEquals(14.0, ExpressionEvaluator.evaluate("2 + 3 * 4"), 0.000001);
    }

    @Test
    public void supportsParenthesesAndUnaryMinus() {
        assertEquals(-10.0, ExpressionEvaluator.evaluate("-(2 + 3) * 2"), 0.000001);
    }

    @Test
    public void supportsDecimalComma() {
        assertEquals(3.75, ExpressionEvaluator.evaluate("1,5 + 2,25"), 0.000001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void rejectsDivisionByZero() {
        ExpressionEvaluator.evaluate("5 / (3 - 3)");
    }
}
