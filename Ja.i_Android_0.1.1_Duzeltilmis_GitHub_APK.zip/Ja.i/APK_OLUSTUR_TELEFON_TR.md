# Ja.i APK oluşturma — Android telefon

Bu paket bir **Android kaynak projesidir**, APK değildir. ZIP dosyasının uzantısını `.apk` yapmak kurulum dosyası oluşturmaz.

## GitHub Actions ile APK (önerilen)

1. Bu ZIP'i telefonunda çıkar.
2. ZIP'in kökündeki `.github` klasörünü ve `Ja.i` klasörünü birlikte GitHub deposunun köküne yükle. `.github/workflows/android.yml` yolunun depo kökünde bulunması şarttır.
3. GitHub deposunda **Actions** sekmesini aç.
4. **Ja.i Android APK** iş akışını seçip **Run workflow** düğmesine bas. Ana dala kod gönderildiğinde iş akışı otomatik de çalışır.
5. Derleme yeşil tikle biterse çalıştırmanın **Artifacts** bölümünden `Ja.i-debug-apk` dosyasını indir.
6. Artifact ZIP'ini çıkar ve içindeki `app-debug.apk` dosyasını Android telefonuna indirip kur.

Bu akış GitHub'ın geçici derleme makinesinde JDK, Android SDK ve Gradle kurar. APK'yı Ja.i uygulaması kendi başına üretmez. İş akışı yalnızca debug APK üretir; imzalı yayın APK'sı oluşturmaz.

## Telefonda yerel derleme

Gerekenler:

- JDK 17
- Android SDK Platform 35 ve Android Build-Tools 35.0.0
- Gradle 8.9 dağıtımını indirebilmek için internet
- Gradle/Android projesi destekleyen bir mobil geliştirme ortamı

Adımlar:

1. ZIP'i çıkar ve `Ja.i` klasörünü geliştirme uygulamasında proje olarak aç.
2. JDK 17 ile Android SDK Platform 35'in kurulu olduğundan emin ol.
3. Proje klasöründe terminal açıp `sh ./build-apk.sh` komutunu çalıştır.
4. Başarılı derlemede APK şu konumda oluşur: `app/build/outputs/apk/debug/app-debug.apk`.

## Sürüm gereksinimi

`minSdk 26` Android 8.0 (Oreo) ve üzerini destekler. Bu, Android 10 demek değildir; daha eski uyumlu sürümleri de kapsar.

## Derleme başarısız olursa

- `SDK location not found`: Android SDK'yı kur ve geliştirme ortamında SDK konumunu tanımla.
- `Failed to find target android-35`: Android SDK Platform 35'i kur.
- `Unsupported class file` veya Java sürümü hatası: JDK 17 kullan.
- Gradle indirme hatası: internet bağlantısını kontrol et.
- GitHub Actions hata verirse iş akışı günlüklerindeki ilk `FAILURE` bölümünü incele.

## Dürüst test durumu

Bu çalışma ortamında Android SDK bulunmadığı için tam APK derlemesi ve gerçek cihaz testi yapılamadı. GitHub iş akışı derleme denemesini yapar; başarılı olup olmadığı GitHub Actions sonucunda belli olur.
